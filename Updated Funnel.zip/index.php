<!doctype html>
<html lang="de">
<head>
<meta name="robots" content="noindex">
    <script crossorigin="anonymous" src="v3/polyfill.min.js"></script>
    <script>window.F1TFunnelsSdkConfig = {language: "de"}</script>
    <script data-type="F1TFunnelSdkJs" src="static/sdk/v1/sdk.js" async="" defer="defer"></script>
    <link data-type="F1TFunnelSdkCss" rel="stylesheet" href="static/sdk/v1/main.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title>Max Income AI</title>
    <link rel="icon" href="assets/images/favi.png" type="image/x-icon">
    <script src="ajax/libs/jquery/3.6.0/jquery.min.js"
            integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="ajax/libs/OwlCarousel2/2.3.1/owl.carousel.min.js"
            integrity="sha512-R5COAyFZ7B88RiuYmY3RPq1uXLFAmRQoGhNF5NU+HaaROvzZ773eLF1guAY8lHM0jNRwgFUVuHWbfPacHXbfDQ=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link href="css/main.4fdd9cb2029ab9d8f7b0.css" rel="stylesheet">
    <link href="https://intl-tel-input.com/intl-tel-input/css/intlTelInput.css?1710935347720" rel="stylesheet">
    <style>
        .f1t-modal__image--loading:not(.f1t-modal__image--error) {
            background-image: url(../static/sdk/v1/fbd3eec9ebb1adc10a56.gif);
            background-size: 30px;
        }

        .f1t-modal--error .f1t-modal__subtitle span {
            color: #f70f0f;
        }

        .f1t-modal--success .f1t-modal__title span {
            color: #28a745;
        }
        .iti__flag {
            background-position: var(--iti-flag-offset) 0 !important;
        }
    </style>
     <style>header .logo {
  width: 100%;
}</style>
</head>
<body>
<header>
    <div class="float-left"><img class="logo" src="assets/images/maxincomeai-bh.svg" alt="Max Income AI"></div>
    <div class="float-right">
        <div class="spots d-none d-lg-none d-xl-block"><span class="flag flag-icon"></span>
            <p class="hurry">Eile ! Nur noch <span class="spotsLeft">43</span> Plätze in <span
                        class="f1t-geo-country-name"></span></p></div>
    </div>
    <div class="clearfix"></div>
</header>
<div class="section-1" id="find-out-how">
    <div class="">
        <div class="container"><h1>Verdienen Sie €950 bis €2200 pro Tag mit der weltweit intelligentesten
                Crypto-Software</h1>
            <div class="row">
                <div class="col-lg-8">
                    <div class="video embed-responsive embed-responsive-16by9 embed-responsive-video">
                        <div>
                            <iframe src="https://iframe.cloudflarestream.com/918b31be9af3e2f3c9b1e328f809d56b?muted=true&autoplay=true"
                                    style="border:none;position:absolute;top:0;height:100%;width:100%"
                                    allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;"
                                    allowfullscreen="true"></iframe>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-box">
                        <div class="f1t-form-custom"><?php include 'form.php'; ?></div>
                    </div>
                </div>
            </div>
            <img class="brands" src="assets/images/assurance-logos.webp" alt="">
            <h3>Heute ist Ihre Chance uns Gesellschaft zu leisten und sofort Geld zu verdienen!</h3></div>
    </div>
</div>
<div class="assets-eur">
    <div class="container">
        <div class="owl-carousel owl-theme">
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="item">
                <div class="win">
                    <div class="person-icon"></div>
                    <p><span class="name">Luke B: </span><span class="money">€190.00</span></p>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section-2">
    <div class="">
        <div class="container"><p class="title">Wie gesehen bei</p>
            <div class="row">
                <div class="col-md-4">
                    <div class="box"><img src="assets/images/bloomberg.webp" alt="">
                        <p class="text">Die beste Investition des Jahrzehnts macht aus 1 Euro 90.000 Euro</p>
                        <hr>
                        <p class="date"><span class="2days-date"></span></p></div>
                </div>
                <div class="col-md-4">
                    <div class="box"><img src="assets/images/ft.webp" alt="">
                        <p class="text">Kein Virus leidet für Investoren, da Bitcoin auf den höchsten Stand aller Zeiten
                            für Menschen von zu Hause aus steigt!</p>
                        <hr>
                        <p class="date"><span class="2days-date"></span></p></div>
                </div>
                <div class="col-md-4">
                    <div class="box"><img src="assets/images/cnn.webp" alt="">
                        <p class="text">Bitcoin SkyRockets auf Allzeithochs Bieten sicheres Einkommen für Tausende in
                            Quarantäne</p>
                        <hr>
                        <p class="date"><span class="yesterday-date"></span></p></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 offset-md-3 col-lg-4 offset-lg-4"><a class="btn" href="#find-out-how">Fordern Sie
                        jetzt Ihren Platz an</a></div>
            </div>
            <h2>Die ganze Kraft, die Sie brauchen, an Ihren Fingerspitzen!</h2></div>
    </div>
</div>
<div class="section-3">
    <div class="container"><img src="assets/images/tablet.webp" alt=""></div>
</div>
<div class="section-4">
    <div class="container"><h2>Max Income AI verwendet künstliche Intelligenz und modernste Algorithmen, um die
            einzig profitablen Handel zu identifizieren</h2>
        <div class="row">
            <div class="col-md-6"><img src="assets/images/bitcoin.webp" alt=""></div>
            <div class="col-md-6"><p>Da sich die Weltwirtschaft und die Aktienmärkte im freien Fall befinden, ist diese
                    Kryptowährung um über 400% gestiegen. Economists In Shock als Bitcoin Out bietet Aktien wie nie
                    zuvor.
                    Mit Bitcoin ist die Zukunft besser</p><a class="btn" href="#find-out-how">Fordern Sie jetzt Ihren
                    Platz
                    an</a></div>
        </div>
    </div>
</div>
<div class="section-5">
    <div class="container"><h3 class="title">Komplette Anfänger verdienen sofort und Sie werden es auch</h3>
        <p class="subtitle">Max Income AI ist so programmiert, dass es nur dann handelt, wenn es weiß, dass es
            einen sofortigen Gewinn erzielt</p>
        <div class="row">
            <div class="col-md-4">
                <div class="box"><img src="assets/images/prof-a.webp" alt="">
                    <p class="name">Jonathan Mulberry</p>
                    <hr>
                    <p class="text">Ich will einfach nur ein großes Dankeschön aussprechen, weil Max Income AI
                        wirklich mein Leben verändert hat. Innerhalb von wenigen Wochen, war ich in der Lage meinen Job
                        zu kündigen!</p>
                    <hr>
                    <div class="bottom">
                        <div class="float-left"><span class="flag flag-icon"></span></div>
                        <div class="float-left"><p class="date"><span class="f1t-date-current-day"></span> <span
                                        class="f1t-date-current-month"></span> <span
                                        class="f1t-date-current-year"></span></p>
                        </div>
                        <div class="float-right"><p class="profit">€ 5,977</p></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="box"><img src="assets/images/prof-b.webp" alt="">
                    <p class="name">Delilah Adams</p>
                    <hr>
                    <p class="text">Diese Sache funktioniert wirklich! Es ist wunderbar. Ich habe es lediglich ein paar
                        Wochen verwendet und schon mehr Geld damit verdient, als wenn ich meinen Hintern bei der Arbeit
                        monatelang aufgerissen habe!</p>
                    <hr>
                    <div class="bottom">
                        <div class="float-left"><span class="flag flag-icon"></span></div>
                        <div class="float-left"><p class="date"><span class="f1t-date-current-day"></span> <span
                                        class="f1t-date-current-month"></span> <span
                                        class="f1t-date-current-year"></span></p>
                        </div>
                        <div class="float-right"><p class="profit">€ 11,369</p></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="box"><img src="assets/images/prof-c.webp" alt="">
                    <p class="name">Simon Horsham</p>
                    <hr>
                    <p class="text">Ich habe meine Kündigung vor zwei Wochen erhalten. Ohne irgendwelche Alternativen
                        habe ich gedacht, wäre mein Leben zu Ende. Jetzt verdiene ich ungefähr €13,261.42 jede Woche!
                        Und zum ersten Mal in 2 Monaten tappe ich nicht mehr im Dunklen! Danke Edwin!</p>
                    <hr>
                    <div class="bottom">
                        <div class="float-left"><span class="flag flag-icon"></span></div>
                        <div class="float-left"><p class="date"><span class="f1t-date-current-day"></span> <span
                                        class="f1t-date-current-month"></span> <span
                                        class="f1t-date-current-year"></span></p>
                        </div>
                        <div class="float-right"><p class="profit">€ 33,426</p></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        <p class="big-title">Registrieren Sie sich noch heute, um sofortigen Zugang zu diesem revolutionären Programm zu
            erhalten</p>
        <p class="big-sub-title">Bank Big Ergebnis heute ...</p>
        <div class="form-box">
            <div class="f1t-form-custom"><?php include 'form.php'; ?></div>
        </div>
    </div>
</div>
<div class="section-6">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="box"><img src="assets/images/asset-1.webp" alt="">
                    <p>Sicher und privat</p></div>
            </div>
            <div class="col-md-4">
                <div class="box"><img src="assets/images/asset-2.webp" alt="">
                    <p>Vertrauenswürdige Leistung</p></div>
            </div>
            <div class="col-md-4">
                <div class="box"><img src="assets/images/asset-3.webp" alt="">
                    <p>Einfach und sicher</p></div>
            </div>
        </div>
    </div>
    <h3><span class="blue" id="number-amount">13627</span> Verdient durch Mitglieder in <span
                class="blue f1t-geo-country-name"></span> bis zu €126.67 in der Stunde</h3></div>
<div class="section-7">
    <div class="container">
        <div class="col-md-8 offset-md-4 col-lg-6 offset-lg-6"><h3 class="title">Max Income AI arbeitet jetzt mit
                allen bedeutenden Crypto Währungsumrechnern</h3>
            <p class="text">Das Geheimnis gründet sich auf den Methoden, wie die Börsen arbeiten. Der Preis von den
                Münzen geht hoch und wieder herunter, je nach Angebot und Nachfrage und das Angebot und die Nachfrage
                für die Währungen ist unterschiedlich je nach Austausch. Deswegen gibt es oft einen RIESIGEN
                Preisunterschied bei denselben Münzen bei unterschiedlichen Austäuschen. Max Income AI vernetzt
                sich nahtlos mit Coinbase, Binance, Kraken, Poloniex, Bittrex und vielen weiteren, um Ihnen einen
                Max Income AI und sofortige Einnahmen zu verleihen.<br><br><span class="yesterday-date"></span>
            </p><img src="assets/images/bloomberg-logo.webp" alt=""> <a class="btn" href="#find-out-how">Verdienen Sie
                noch heute</a></div>
    </div>
</div>
<div class="section-8">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="box"><img src="assets/images/prof-d.webp" alt="">
                    <p class="name">Lewis Tucker</p>
                    <hr>
                    <p class="text">Ich komme nicht darüber hinweg. € 43,568 in nur 30 Tagen. Ich bin so dankbar.</p>
                    <hr>
                    <div class="bottom">
                        <div class="float-left"><span class="flag flag-icon"></span></div>
                        <div class="float-left"><p class="date"><span class="f1t-date-current-day"></span> <span
                                        class="f1t-date-current-month"></span> <span
                                        class="f1t-date-current-year"></span></p>
                        </div>
                        <div class="float-right"><p class="profit">€ 12,896</p></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="box"><img src="assets/images/prof-e.webp" alt="">
                    <p class="name">Georgina Barry</p>
                    <hr>
                    <p class="text">Mein Betriebskonto hat jetzt € 231,952. Können Sie das glauben!</p>
                    <hr>
                    <div class="bottom">
                        <div class="float-left"><span class="flag flag-icon"></span></div>
                        <div class="float-left"><p class="date"><span class="f1t-date-current-day"></span> <span
                                        class="f1t-date-current-month"></span> <span
                                        class="f1t-date-current-year"></span></p>
                        </div>
                        <div class="float-right"><p class="profit">€ 49,279</p></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="box"><img src="assets/images/prof-f.webp" alt="">
                    <p class="name">Owen Spencer</p>
                    <hr>
                    <p class="text">Ich bin so sprachlos. Ich habe nie zuvor solche Zahlen gesehen. Danke, Max Income AI!</p>
                    <hr>
                    <div class="bottom">
                        <div class="float-left"><span class="flag flag-icon"></span></div>
                        <div class="float-left"><p class="date"><span class="f1t-date-current-day"></span> <span
                                        class="f1t-date-current-month"></span> <span
                                        class="f1t-date-current-year"></span></p>
                        </div>
                        <div class="float-right"><p class="profit">€ 7,899</p></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        <p class="big-title">Einfacher Zugang, sofortiges Einkommen</p>
        <p class="big-sub-title">Melden Sie sich kostenlos an, um loszulegen</p>
        <div class="form-box">
            <div class="f1t-form-custom"><?php include 'form.php'; ?></div>
        </div>
    </div>
</div>
<div class="section-9">
    <div class="container"><img class="logo-fb" src="assets/images/fb-logo.webp" alt="">
        <hr>
        <p class="date"><span class="facebook-date"></span></p>
        <hr>
        <div class="box">
            <div class="row">
                <div class="col-md-2 col-sm-3">
                    <div class="user-img"><img class="./assets/images-responsive" src="assets/images/fb-user.webp"
                                               alt=""></div>
                </div>
                <div class="col-md-10 col-sm-9"><p class="name">Joanne Bowyer</p>
                    <div class="star"><span class="icon-icon icon-four-stars"></span></div>
                    <div class="text">Ich habe zuvor nie gehandelt, aber Max Income AI macht es so einfach. Ich
                        habe niemals gedacht, dass ich das sagen würde, da die Crypto-Welt so kompliziert sein
                        kann...aber Sie machen es so einfach unvorstellbare Summen zu verdienen!
                    </div>
                    <div class="like"><a href="#"><i class="far fa-thumbs-up"></i>Like</a> <a href="#"><i
                                    class="far fa-comment"></i>Comment</a></div>
                </div>
            </div>
        </div>
        <hr>
        <div class="box">
            <div class="row">
                <div class="col-md-2 col-sm-3">
                    <div class="user-img"><img class="./assets/images-responsive" src="assets/images/fb-user-2.webp"
                                               alt=""></div>
                </div>
                <div class="col-md-10 col-sm-9"><p class="name">Rudy Perkins</p>
                    <div class="star"><span class="icon-icon icon-five-stars"></span></div>
                    <div class="text">Das ist genau das, auf was ich gewartet habe! Ihre Bildungsförderung und
                        hochlukratives Geschäft hat mich für mein ganzes Leben lang süchtig gemacht! Vielen Dank
                    </div>
                    <div class="like"><a href="#"><i class="far fa-thumbs-up"></i>Like</a> <a href="#"><i
                                    class="far fa-comment"></i>Comment</a></div>
                </div>
            </div>
        </div>
        <hr>
        <div class="box">
            <div class="row">
                <div class="col-md-2 col-sm-3">
                    <div class="user-img"><img class="./assets/images-responsive" src="assets/images/fb-user-3.webp"
                                               alt=""></div>
                </div>
                <div class="col-md-10 col-sm-9"><p class="name">Clark Ross</p>
                    <div class="star"><span class="icon-icon icon-four-stars"></span></div>
                    <div class="text">An meinem ersten Tag habe ich über 900 Euro verdient, deshalb kann ich wirklich
                        sagen…Ich habe endlich etwas gefunden, dass großartige Ergebnisse liefert!
                    </div>
                    <div class="like"><a href="#"><i class="far fa-thumbs-up"></i>Like</a> <a href="#"><i
                                    class="far fa-comment"></i>Comment</a></div>
                </div>
            </div>
        </div>
        <hr>
        <div class="box">
            <div class="row">
                <div class="col-md-2 col-sm-3">
                    <div class="user-img"><img class="./assets/images-responsive" src="assets/images/fb-user-4.webp"
                                               alt=""></div>
                </div>
                <div class="col-md-10 col-sm-9"><p class="name">Steven Shuler</p>
                    <div class="star"><span class="icon-icon icon-four-stars"></span></div>
                    <div class="text">Das Geld auf meinem Account seit dem ersten Tag. Ich kann das immer noch nicht
                        glauben… Ich liebe unser System und das Unterstützerteam ist ausgezeichnet!
                    </div>
                    <div class="like"><a href="#"><i class="far fa-thumbs-up"></i>Like</a> <a href="#"><i
                                    class="far fa-comment"></i>Comment</a></div>
                </div>
            </div>
        </div>
        <hr>
    </div>
</div>
<footer>
    <div class="container"><img class="logo" src="assets/images/maxincomeai-bh-blk.svg" alt="">
        <h3 class="title">Warum warten und zusehen, wie andere Geld verdienen?</h3>
        <p class="sub-title">Es ist einfach, wenn Sie wissen, wie</p>
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="form-box">
                    <div class="f1t-form-custom"><?php include 'form.php'; ?></div>
                </div>
            </div>
        </div>
        <hr>
        <p class="text">Wichtiger Hinweis: Der Handel mit Devisen und CFDs birgt aufgrund der Hebelwirkung des Handels
            ein hohes Verlustrisiko, das zum Totalverlust Ihres Kapitals führen kann und möglicherweise nicht für alle
            Arten von Anlegern geeignet ist. Bitte lesen Sie unsere vollständige Risikowarnung und den entsprechenden
            Broker, bei dem Sie registriert sind, um sicherzustellen, dass Sie die damit verbundenen Risiken verstehen,
            bevor Sie fortfahren, und berücksichtigen Sie dabei Ihre relevanten Erfahrungen. Lassen Sie sich bei Bedarf
            von einem unabhängigen Berater beraten. Die auf dieser Website und in den Offenlegungsdokumenten enthaltenen
            Informationen sind nur allgemeiner Natur und berücksichtigen nicht Ihre persönlichen Umstände, Ihre
            finanzielle Situation oder Ihre Bedürfnisse. Sie sollten die Brokerage-Kundenvereinbarung sorgfältig prüfen
            und unabhängigen Rat einholen, bevor Sie entscheiden, ob der Handel mit solchen Produkten für Sie geeignet
            ist.</p>
        <p class="text-credentials">© <span class="f1t-date-current-year"></span> Alle Rechte vorbehalten - Max Income AI</p></div>
</footer>
<div id="earningsPopup" class="just-made">
    <div class="float-left"><p class="name">Jay M Made</p><span class="blue">€ 1093.20</span></div>
    <div class="float-right">
        <div class="avatar"><span class="flag flag-icon"></span></div>
    </div>
    <div class="clearfix"></div>
</div>
<div id="popup" class="exit-popup">
    <div id="exit-popup" class="inner-popup"><a class="close"
                                                onclick='€("#popup").css("display","none"),mousebottom=0,setTimeout((function(){pu=1}),5e3)'>X</a>
        <img src="assets/images/stop.webp" alt="">
        <p>Bevor Sie irgendwo hingehen, bedenken Sie folgendes: Wenn Sie diese Gelegenheit nicht nutzen, wird <strong>JETZT</strong>
            jemand Ihren Platz einnehmen.</p>
        <p class="subtitle">Verpassen Sie nicht Ihre Chance, Ihre finanzielle Zukunft zu ändern!</p>
        <p class="p2">Jetzt loslegen und wir sehen uns auf der Gewinnerseite!</p>
        <div class="form-box pop-form">
            <div class="f1t-form-custom"><?php include 'form.php'; ?></div>
        </div>
    </div>
</div>
<div class="f1t-modal" style="display: none;">
    <div class="f1t-modal__wrapper">
        <div class="f1t-modal__inner">
            <div class="f1t-modal__header">
                <div class="f1t-modal__image f1t-modal__image--loading"></div>
                <div class="f1t-modal__title">Wir senden Ihre <span>Bewerbung</span>!</div>
                <div class="f1t-modal__subtitle">Bitte warten Sie, bis der Vorgang abgeschlossen ist.</div>
            </div>
            <div class="f1t-modal__footer"></div>
        </div>
    </div>
</div>
<script defer="defer" src="js/index.dd4b339a25a64baa0896.js"></script>
<script defer="defer" src="ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/intl-tel-input@20.1.0/build/js/intlTelInput.min.js"></script>
<script>
    (function ($) {
        let disable_form_submit = function () {
            let contactNameField = '[name="first_name"], [name="last_name"], [name="email"], [name="phone"]';

            $(contactNameField).keyup(function () {
                let form = $(this).closest('form');
                let submitButton = form.find('.f1t-form__submit');
                let empty = false;
                form.find(contactNameField).each(function () {
                    if ($(this).val() === '') {
                        empty = true;
                    }
                });
                if (empty) {
                    submitButton.attr('disabled', 'disabled');
                } else {
                    submitButton.removeAttr('disabled');
                }
            });
        };
        $(disable_form_submit);

        $(document).on('submit', 'form.f1t-form__wrapper', function (e) {
            e.preventDefault();
            let $form = $(this),
                serializedData = $form.serialize(),
                modal = $('.f1t-modal');

            modal.fadeIn();
            modal.removeClass('f1t-modal--error');
            modal.find('.f1t-modal__image').removeClass('f1t-modal__image--error');
            modal.find('.f1t-modal__title').html('Wir senden Ihre <span>Bewerbung</span>!');
            modal.find('.f1t-modal__subtitle').html('Bitte warten Sie, bis der Vorgang abgeschlossen ist.');
            modal.find('.f1t-modal__footer').html('');

            let request = $.ajax({
                url: "send_lead.php",
                type: "post",
                data: serializedData
            });
            request.done(function (response) {
                let returnedData = JSON.parse(response),
                    title,
                    subtitle,
                    button;

                if (!returnedData.success) {
                    title = 'Sie haben <span>abgelehnt</span>!';
                    subtitle = 'Sie können sich nicht registrieren. <span>' + returnedData.message + '</span>';
                    button = '<button class="f1t-modal__button js-try-again">Versuch es noch einmal</button>';
                    modal.addClass('f1t-modal--error');
                    modal.find('.f1t-modal__image').addClass('f1t-modal__image--error');
                    modal.find('.f1t-modal__title').html(title);
                    modal.find('.f1t-modal__subtitle').html(subtitle);
                    modal.find('.f1t-modal__footer').html(button);
                } else {
                    modal.addClass('f1t-modal--success');
                    modal.find('.f1t-modal__image').addClass('f1t-modal__image--success');
                    modal.find('.f1t-modal__title').html('Ihre Bewerbung wurde <span>akzeptiert</span>!');
                    modal.find('.f1t-modal__subtitle').html('Sie werden dann auf die Website weitergeleitet. Wenn nichts passiert, klicken Sie auf die Schaltfläche unten.');
                    modal.find('.f1t-modal__footer').html('<a href="' + returnedData.autologin + '" class="f1t-modal__button">Zur Website</a>');
                    setTimeout(function () {
                        window.location.replace(returnedData.autologin);
                    }, 5000);

                }
            });
        });

        $(document).on('click', '.js-try-again', function (e) {
            $('.f1t-modal').hide();
        });

    })(jQuery);

    const inputsPhone = document.querySelectorAll("[name='custom_phone']");
    inputsPhone.forEach(input => {
        window.intlTelInput(input, {
            utilsScript: "../static/sdk/v1/iti-utils.js",
            formatAsYouType: false,
            initialCountry: "DE",
            separateDialCode: true,
            nationalMode: true,
            countrySearch: false,
            hiddenInput: () => ({phone: "full_phone", country: "country_code"}),
        });
    });
</script>
</body>
</html>