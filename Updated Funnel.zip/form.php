<form class="f1t-form__wrapper" method="post">
    <div class="f1t-form__inner">
        <div class="f1t-form__row" data-input-container="2714" data-error="true">
            <div class="f1t-form-field f1t-form-field--text">
                <label>
                    <div class="f1t-form-field__label">Vorname</div>
                    <input type="text" placeholder="Bitte Vornamen eingeben" name="first_name" data-name="first_name"
                           data-validation="{&quot;required&quot;:true}" data-type="text" data-input=""
                           data-uniqid="2714" data-error="true">
                </label>
            </div>
            <div class="f1t-form-field__error data-error-2714"></div>
        </div>
        <div class="f1t-form__row" data-input-container="565" data-error="true">
            <div class="f1t-form-field f1t-form-field--text">
                <label>
                    <div class="f1t-form-field__label">Nachname</div>
                    <input type="text" placeholder="Nachnamen eingeben" name="last_name" data-name="last_name"
                           data-validation="{&quot;required&quot;:true}" data-type="text" data-input=""
                           data-uniqid="565" data-error="true">
                </label>
            </div>
            <div class="f1t-form-field__error data-error-565"></div>
        </div>
        <div class="f1t-form__row" data-input-container="954" data-error="true">
            <div class="f1t-form-field f1t-form-field--email">
                <label>
                    <div class="f1t-form-field__label">E-mail</div>
                    <input type="email" placeholder="Email eingeben" name="email" data-name="email"
                           data-validation="{&quot;required&quot;:true,&quot;type&quot;:&quot;email&quot;}"
                           data-type="email" data-input="" data-uniqid="954" data-error="true">
                </label>
            </div>
            <div class="f1t-form-field__error data-error-954"></div>
        </div>
        <div class="f1t-form__row" data-input-container="9546" data-error="true">
            <div class="f1t-form-field f1t-form-field--phone">
                <label>
                    <div class="f1t-form-field__label">Telefon</div>
                    <input type="tel" placeholder="Dein Handy" name="custom_phone" data-name="custom_phone"
                           style="padding-left: 104px;">

                    <!--                        <input type="tel" placeholder="Dein Handy" name="phone" data-name="phone"-->
                    <!--                               data-validation="{&quot;required&quot;:true,&quot;min&quot;:&quot;6&quot;,&quot;type&quot;:&quot;phone&quot;}"-->
                    <!--                               data-type="phone" data-input="" data-uniqid="9546" autocomplete="off"-->
                    <!--                               data-intl-tel-input-id="0" style="padding-left: 104px;" data-error="true"><input-->
                    <!--                                hidden="" data-name="PHONE_WITH_CODE" data-input="" data-error="false">-->
                </label>
            </div>
            <div class="f1t-form-field__error data-error-9546"></div>
        </div>
        <input type="hidden" name="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
        <input type="hidden" name="click_id"
               value="<?php echo ! empty( $_GET['click_id'] ) ? $_GET['click_id'] : ''; ?>">
        <input type="hidden" name="link_id"
               value="<?php echo ! empty( $_GET['link_id'] ) ? $_GET['link_id'] : 5; ?>">
        <div class="f1t-form__row" data-input-container="9032">
            <div class="f1t-form-field f1t-form-field--submit">
                <button class="f1t-form__submit" type="submit" name="submit" data-name="submit"
                        value="Jetzt registrieren" disabled>
                    Jetzt registrieren
                </button>
            </div>
            <div class="f1t-form-field__error data-error-9032"></div>
        </div>
    </div>
</form>