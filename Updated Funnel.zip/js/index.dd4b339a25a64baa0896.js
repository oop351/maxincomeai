(() => {
    var e = {
        163: () => {
            var e = new Date;
            e.setDate(e.getDate() - 2), $(".2days-date").text(e.toDateString());
            var n = new Date;
            n.setDate(n.getDate() - 1), $(".yesterday-date").text(n.toDateString());
            var o = new Date;
            o.setDate(o.getDate()), $(".facebook-date").text(o.toLocaleString())
        }, 90: () => {
            var e = 0;
            document.addEventListener("mouseleave", (function (n) {
                n.clientY < 0 && e < 2 && ($("#popup").hasClass("open") || ($("body").css("overflow", "hidden"), $("#popup").css("display", "block"), e++))
            }), !1), $("#exit-popup .close").click((function () {
                $("#popup").hide(), $("body").css("overflow", "auto")
            }))
        }
    }, n = {};

    function o(a) {
        var t = n[a];
        if (void 0 !== t) return t.exports;
        var m = n[a] = {exports: {}};
        return e[a](m, m.exports, o), m.exports
    }

    (() => {
        "use strict";
        var e = [{name: "Maila Hahn", gender: "female", photo: "icon-f-1"}, {
            name: "Jan Voigt",
            gender: "male",
            photo: "icon-m-1"
        }, {name: "Xenia Graf", gender: "female", photo: "icon-f-19"}, {
            name: "Nico Frank",
            gender: "male",
            photo: "icon-m-1"
        }, {name: "Lea Scholz", gender: "female", photo: "icon-f-5"}, {
            name: "Fiona Otto",
            gender: "female",
            photo: "icon-f-24"
        }, {name: "Romy Wolf", gender: "female", photo: "icon-f-26"}, {
            name: "Mats Huber",
            gender: "male",
            photo: "icon-m-14"
        }, {name: "Ella Busch", gender: "female", photo: "icon-f-11"}, {
            name: "Sam Ilsner",
            gender: "male",
            photo: "icon-m-9"
        }, {name: "Liam Kraus", gender: "male", photo: "icon-m-14"}, {
            name: "Tom Vogt",
            gender: "male",
            photo: "icon-m-13"
        }, {name: "Joel Busch", gender: "male", photo: "icon-m-4"}, {
            name: "Till Kühn",
            gender: "male",
            photo: "icon-m-3"
        }, {name: "Leon Busch", gender: "male", photo: "icon-m-20"}, {
            name: "Finn Horn",
            gender: "male",
            photo: "icon-m-10"
        }, {name: "Aaron Koch", gender: "male", photo: "icon-m-14"}, {
            name: "Karl Thoma",
            gender: "male",
            photo: "icon-m-2"
        }, {name: "Erik Horn", gender: "male", photo: "icon-m-4"}, {
            name: "Erik Otto",
            gender: "male",
            photo: "icon-m-16"
        }, {name: "John Groß", gender: "male", photo: "icon-m-18"}, {
            name: "Leni Klein",
            gender: "female",
            photo: "icon-f-12"
        }, {name: "Zoe Engel", gender: "female", photo: "icon-f-7"}, {
            name: "Mia Lange",
            gender: "female",
            photo: "icon-f-18"
        }, {name: "Max Koch", gender: "male", photo: "icon-m-3"}, {
            name: "Nils Horn",
            gender: "male",
            photo: "icon-m-10"
        }, {name: "Elisa Roth", gender: "female", photo: "icon-f-23"}, {
            name: "Mara Kraus",
            gender: "female",
            photo: "icon-f-20"
        }, {name: "Julia Jung", gender: "female", photo: "icon-f-1"}, {
            name: "Max Otto",
            gender: "male",
            photo: "icon-m-9"
        }, {name: "Till Busch", gender: "male", photo: "icon-m-2"}, {
            name: "Jakob Haas",
            gender: "male",
            photo: "icon-m-1"
        }, {name: "Noah Weiß", gender: "male", photo: "icon-m-14"}, {
            name: "Eva Sauer",
            gender: "female",
            photo: "icon-f-10"
        }, {name: "Lukas Graf", gender: "male", photo: "icon-m-12"}, {
            name: "Phil Maier",
            gender: "male",
            photo: "icon-m-20"
        }, {name: "Jona Huber", gender: "male", photo: "icon-m-10"}, {
            name: "Carla Otto",
            gender: "female",
            photo: "icon-f-3"
        }, {name: "Tim Becker", gender: "male", photo: "icon-m-18"}, {
            name: "Lenny Horn",
            gender: "male",
            photo: "icon-m-11"
        }, {name: "Luna Weber", gender: "female", photo: "icon-f-21"}, {
            name: "Toni Thoma",
            gender: "male",
            photo: "icon-m-3"
        }, {name: "Mina Rams", gender: "female", photo: "icon-f-19"}, {
            name: "Maja Pohl",
            gender: "female",
            photo: "icon-f-5"
        }, {name: "Leon Lang", gender: "male", photo: "icon-m-2"}, {
            name: "Noel Haas",
            gender: "male",
            photo: "icon-m-19"
        }, {name: "Noel Wolf", gender: "male", photo: "icon-m-2"}, {
            name: "Max Maier",
            gender: "male",
            photo: "icon-m-15"
        }, {name: "Colin Rams", gender: "male", photo: "icon-m-2"}, {
            name: "Tim Jäger",
            gender: "male",
            photo: "icon-m-4"
        }];

        function n(e, n, o) {
            var a = Math.ceil(e + Math.random() * (n + 1 - e));
            return "eur" == o ? a.toLocaleString("en-US", {
                style: "currency",
                currency: "EUR"
            }) : "eur" == o ? a.toLocaleString("en-US", {style: "currency", currency: "eur"}) : a
        }

        var a;
        o(90), o(163);
        setInterval((function () {
            $(".just-made .name").each((function (n, o) {
                $(this).text(e[n].name)
            })), $(".just-made .avatar").each((function (n, o) {
                $(this).addClass(e[n].photo)
            })), $(".just-made .blue").each((function (e, o) {
                $(this).text(n(108, 972, "eur"))
            })), $("#earningsPopup").fadeIn().delay(6e3).fadeOut()
        }), 14e3), $("#number-amount").text(n(987567, 1479882, "eur")),
            $("#to-number-amount").text(n(126, 220, "eur")),
            $("#number-amount-eur").text(n(987567, 1479882, "eur")),
            $("#to-number-amount-eur").text(n(126, 220, "eur")), function () {
            for (var e = arguments.length, n = new Array(e), o = 0; o < e; o++) n[o] = arguments[o];
            sdkEvents$.on("sdk:countryCode").subscribe((function (e) {
                n.forEach((function (n) {
                    return n(e)
                }))
            }))
        }(function (e) {
            var n = document.querySelectorAll(e);
            if (n.length) return function (e) {
                e && n.forEach((function (n) {
                    return n.classList.add("flag-icon-de")
                    // return n.classList.add("flag-icon-".concat(e.toLowerCase()))
                }))
            }
        }(".flag")), a = e, $(".assets .name").each((function (e, n) {
            $(this).text(a[e].name)
        })), $(".assets .person-icon").each((function (e, n) {
            $(this).addClass(a[e].photo)
        })), $(".assets .money").each((function (e, o) {
            $(this).text(n(108, 972, "eur"))
        })), $(".assets-eur .name").each((function (e, n) {
            $(this).text(a[e].name)
        })), $(".assets-eur .person-icon").each((function (e, n) {
            $(this).addClass(a[e].photo)
        })), $(".assets-eur .money").each((function (e, o) {
            $(this).text(n(108, 972, "eur"))
        })), $(".owl-carousel").owlCarousel({
            loop: !0,
            margin: 0,
            autoplay: !0,
            slideTransition: "linear",
            autoplayTimeout: 0,
            autoplaySpeed: 7e3,
            autoplayHoverPause: !1,
            dots: !1,
            nav: !1,
            responsiveClass: !0,
            responsive: {0: {items: 1}, 600: {items: 1}, 1e3: {items: 2}, 1410: {items: 3}}
        })
    })()
})();