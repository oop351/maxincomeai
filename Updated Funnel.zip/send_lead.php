<?php
if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
	// Retrieve form data
	$first_name = $_POST['first_name'];
	$last_name  = $_POST['last_name'];
	$email      = $_POST['email'];
	$phone      = $_POST['full_phone'];
	$user_ip    = $_POST['user_ip'];
	$country    = $_POST['country_code'];

	$source   = 'maxincomeai-p-de';
	$link_id  = $_POST['link_id'];
	$click_id = $_POST['click_id'];

	// Validate and sanitize the data (example validation)
	if ( empty( $firstname ) || empty( $lastName ) || empty( $email ) || empty( $phone ) ) {
		// Handle validation error (e.g., display an error message)
		$msg = "Error! Please fill in all the fields.";
	}

	// Prepare data for API request
	$data = array(
		// required data
		'link_id'   => $link_id,
		'fname'     => $first_name,
		'email'     => $email,
		'fullphone' => $phone,
		'source'    => $source,
		'ip'        => $user_ip,
		'country'   => $country,
		'language'  => $country,
		// optional data
		'lname'     => $last_name,
		'click_id'  => $click_id,
	);

	$curl = curl_init();
	curl_setopt_array( $curl, array(
		CURLOPT_URL            => 'https://tracking.spartans360.com/api/v3/integration?api_token=mBL1aVwCtWptaNsWoFZ7wOFs0Nznq69fX2irnznsfwgV580stoJhFASdiobu',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING       => '',
		CURLOPT_MAXREDIRS      => 10,
		CURLOPT_TIMEOUT        => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST  => 'POST',
		CURLOPT_POSTFIELDS     => $data,
	) );

	$response = curl_exec( $curl );

	curl_close( $curl );

	// return json response
	echo $response;
}
